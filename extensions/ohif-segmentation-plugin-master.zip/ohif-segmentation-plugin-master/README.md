# ohif-segmentation-plugin

WIP, drafted in NAMIC Project week 31.

This will be fleshed out in due course!
